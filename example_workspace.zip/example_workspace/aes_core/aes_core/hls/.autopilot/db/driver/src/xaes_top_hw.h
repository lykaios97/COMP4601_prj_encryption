// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x000 : Control signals
//         bit 0  - ap_start (Read/Write/COH)
//         bit 1  - ap_done (Read/COR)
//         bit 2  - ap_idle (Read)
//         bit 3  - ap_ready (Read/COR)
//         bit 7  - auto_restart (Read/Write)
//         bit 9  - interrupt (Read)
//         others - reserved
// 0x004 : Global Interrupt Enable Register
//         bit 0  - Global Interrupt Enable (Read/Write)
//         others - reserved
// 0x008 : IP Interrupt Enable Register (Read/Write)
//         bit 0 - enable ap_done interrupt (Read/Write)
//         bit 1 - enable ap_ready interrupt (Read/Write)
//         others - reserved
// 0x00c : IP Interrupt Status Register (Read/TOW)
//         bit 0 - ap_done (Read/TOW)
//         bit 1 - ap_ready (Read/TOW)
//         others - reserved
// 0x010 ~
// 0x01f : Memory 'in_r' (16 * 8b)
//         Word n : bit [ 7: 0] - in_r[4n]
//                  bit [15: 8] - in_r[4n+1]
//                  bit [23:16] - in_r[4n+2]
//                  bit [31:24] - in_r[4n+3]
// 0x020 ~
// 0x02f : Memory 'out_r' (16 * 8b)
//         Word n : bit [ 7: 0] - out_r[4n]
//                  bit [15: 8] - out_r[4n+1]
//                  bit [23:16] - out_r[4n+2]
//                  bit [31:24] - out_r[4n+3]
// 0x100 ~
// 0x1ff : Memory 'w' (44 * 32b)
//         Word n : bit [31:0] - w[n]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XAES_TOP_CONTROL_ADDR_AP_CTRL    0x000
#define XAES_TOP_CONTROL_ADDR_GIE        0x004
#define XAES_TOP_CONTROL_ADDR_IER        0x008
#define XAES_TOP_CONTROL_ADDR_ISR        0x00c
#define XAES_TOP_CONTROL_ADDR_IN_R_BASE  0x010
#define XAES_TOP_CONTROL_ADDR_IN_R_HIGH  0x01f
#define XAES_TOP_CONTROL_WIDTH_IN_R      8
#define XAES_TOP_CONTROL_DEPTH_IN_R      16
#define XAES_TOP_CONTROL_ADDR_OUT_R_BASE 0x020
#define XAES_TOP_CONTROL_ADDR_OUT_R_HIGH 0x02f
#define XAES_TOP_CONTROL_WIDTH_OUT_R     8
#define XAES_TOP_CONTROL_DEPTH_OUT_R     16
#define XAES_TOP_CONTROL_ADDR_W_BASE     0x100
#define XAES_TOP_CONTROL_ADDR_W_HIGH     0x1ff
#define XAES_TOP_CONTROL_WIDTH_W         32
#define XAES_TOP_CONTROL_DEPTH_W         44

