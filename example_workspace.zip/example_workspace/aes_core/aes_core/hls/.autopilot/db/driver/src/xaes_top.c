// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xaes_top.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XAes_top_CfgInitialize(XAes_top *InstancePtr, XAes_top_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XAes_top_Start(XAes_top *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAes_top_ReadReg(InstancePtr->Control_BaseAddress, XAES_TOP_CONTROL_ADDR_AP_CTRL) & 0x80;
    XAes_top_WriteReg(InstancePtr->Control_BaseAddress, XAES_TOP_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XAes_top_IsDone(XAes_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAes_top_ReadReg(InstancePtr->Control_BaseAddress, XAES_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XAes_top_IsIdle(XAes_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAes_top_ReadReg(InstancePtr->Control_BaseAddress, XAES_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XAes_top_IsReady(XAes_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAes_top_ReadReg(InstancePtr->Control_BaseAddress, XAES_TOP_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XAes_top_EnableAutoRestart(XAes_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAes_top_WriteReg(InstancePtr->Control_BaseAddress, XAES_TOP_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XAes_top_DisableAutoRestart(XAes_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAes_top_WriteReg(InstancePtr->Control_BaseAddress, XAES_TOP_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XAes_top_Get_in_r_BaseAddress(XAes_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XAES_TOP_CONTROL_ADDR_IN_R_BASE);
}

u32 XAes_top_Get_in_r_HighAddress(XAes_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XAES_TOP_CONTROL_ADDR_IN_R_HIGH);
}

u32 XAes_top_Get_in_r_TotalBytes(XAes_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XAES_TOP_CONTROL_ADDR_IN_R_HIGH - XAES_TOP_CONTROL_ADDR_IN_R_BASE + 1);
}

u32 XAes_top_Get_in_r_BitWidth(XAes_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAES_TOP_CONTROL_WIDTH_IN_R;
}

u32 XAes_top_Get_in_r_Depth(XAes_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAES_TOP_CONTROL_DEPTH_IN_R;
}

u32 XAes_top_Write_in_r_Words(XAes_top *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XAES_TOP_CONTROL_ADDR_IN_R_HIGH - XAES_TOP_CONTROL_ADDR_IN_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XAES_TOP_CONTROL_ADDR_IN_R_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XAes_top_Read_in_r_Words(XAes_top *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XAES_TOP_CONTROL_ADDR_IN_R_HIGH - XAES_TOP_CONTROL_ADDR_IN_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XAES_TOP_CONTROL_ADDR_IN_R_BASE + (offset + i)*4);
    }
    return length;
}

u32 XAes_top_Write_in_r_Bytes(XAes_top *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XAES_TOP_CONTROL_ADDR_IN_R_HIGH - XAES_TOP_CONTROL_ADDR_IN_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XAES_TOP_CONTROL_ADDR_IN_R_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XAes_top_Read_in_r_Bytes(XAes_top *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XAES_TOP_CONTROL_ADDR_IN_R_HIGH - XAES_TOP_CONTROL_ADDR_IN_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XAES_TOP_CONTROL_ADDR_IN_R_BASE + offset + i);
    }
    return length;
}

u32 XAes_top_Get_out_r_BaseAddress(XAes_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XAES_TOP_CONTROL_ADDR_OUT_R_BASE);
}

u32 XAes_top_Get_out_r_HighAddress(XAes_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XAES_TOP_CONTROL_ADDR_OUT_R_HIGH);
}

u32 XAes_top_Get_out_r_TotalBytes(XAes_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XAES_TOP_CONTROL_ADDR_OUT_R_HIGH - XAES_TOP_CONTROL_ADDR_OUT_R_BASE + 1);
}

u32 XAes_top_Get_out_r_BitWidth(XAes_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAES_TOP_CONTROL_WIDTH_OUT_R;
}

u32 XAes_top_Get_out_r_Depth(XAes_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAES_TOP_CONTROL_DEPTH_OUT_R;
}

u32 XAes_top_Write_out_r_Words(XAes_top *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XAES_TOP_CONTROL_ADDR_OUT_R_HIGH - XAES_TOP_CONTROL_ADDR_OUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XAES_TOP_CONTROL_ADDR_OUT_R_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XAes_top_Read_out_r_Words(XAes_top *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XAES_TOP_CONTROL_ADDR_OUT_R_HIGH - XAES_TOP_CONTROL_ADDR_OUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XAES_TOP_CONTROL_ADDR_OUT_R_BASE + (offset + i)*4);
    }
    return length;
}

u32 XAes_top_Write_out_r_Bytes(XAes_top *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XAES_TOP_CONTROL_ADDR_OUT_R_HIGH - XAES_TOP_CONTROL_ADDR_OUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XAES_TOP_CONTROL_ADDR_OUT_R_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XAes_top_Read_out_r_Bytes(XAes_top *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XAES_TOP_CONTROL_ADDR_OUT_R_HIGH - XAES_TOP_CONTROL_ADDR_OUT_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XAES_TOP_CONTROL_ADDR_OUT_R_BASE + offset + i);
    }
    return length;
}

u32 XAes_top_Get_w_BaseAddress(XAes_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XAES_TOP_CONTROL_ADDR_W_BASE);
}

u32 XAes_top_Get_w_HighAddress(XAes_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XAES_TOP_CONTROL_ADDR_W_HIGH);
}

u32 XAes_top_Get_w_TotalBytes(XAes_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XAES_TOP_CONTROL_ADDR_W_HIGH - XAES_TOP_CONTROL_ADDR_W_BASE + 1);
}

u32 XAes_top_Get_w_BitWidth(XAes_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAES_TOP_CONTROL_WIDTH_W;
}

u32 XAes_top_Get_w_Depth(XAes_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAES_TOP_CONTROL_DEPTH_W;
}

u32 XAes_top_Write_w_Words(XAes_top *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XAES_TOP_CONTROL_ADDR_W_HIGH - XAES_TOP_CONTROL_ADDR_W_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XAES_TOP_CONTROL_ADDR_W_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XAes_top_Read_w_Words(XAes_top *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XAES_TOP_CONTROL_ADDR_W_HIGH - XAES_TOP_CONTROL_ADDR_W_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XAES_TOP_CONTROL_ADDR_W_BASE + (offset + i)*4);
    }
    return length;
}

u32 XAes_top_Write_w_Bytes(XAes_top *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XAES_TOP_CONTROL_ADDR_W_HIGH - XAES_TOP_CONTROL_ADDR_W_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XAES_TOP_CONTROL_ADDR_W_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XAes_top_Read_w_Bytes(XAes_top *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XAES_TOP_CONTROL_ADDR_W_HIGH - XAES_TOP_CONTROL_ADDR_W_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XAES_TOP_CONTROL_ADDR_W_BASE + offset + i);
    }
    return length;
}

void XAes_top_InterruptGlobalEnable(XAes_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAes_top_WriteReg(InstancePtr->Control_BaseAddress, XAES_TOP_CONTROL_ADDR_GIE, 1);
}

void XAes_top_InterruptGlobalDisable(XAes_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAes_top_WriteReg(InstancePtr->Control_BaseAddress, XAES_TOP_CONTROL_ADDR_GIE, 0);
}

void XAes_top_InterruptEnable(XAes_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAes_top_ReadReg(InstancePtr->Control_BaseAddress, XAES_TOP_CONTROL_ADDR_IER);
    XAes_top_WriteReg(InstancePtr->Control_BaseAddress, XAES_TOP_CONTROL_ADDR_IER, Register | Mask);
}

void XAes_top_InterruptDisable(XAes_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAes_top_ReadReg(InstancePtr->Control_BaseAddress, XAES_TOP_CONTROL_ADDR_IER);
    XAes_top_WriteReg(InstancePtr->Control_BaseAddress, XAES_TOP_CONTROL_ADDR_IER, Register & (~Mask));
}

void XAes_top_InterruptClear(XAes_top *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAes_top_WriteReg(InstancePtr->Control_BaseAddress, XAES_TOP_CONTROL_ADDR_ISR, Mask);
}

u32 XAes_top_InterruptGetEnabled(XAes_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAes_top_ReadReg(InstancePtr->Control_BaseAddress, XAES_TOP_CONTROL_ADDR_IER);
}

u32 XAes_top_InterruptGetStatus(XAes_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAes_top_ReadReg(InstancePtr->Control_BaseAddress, XAES_TOP_CONTROL_ADDR_ISR);
}

