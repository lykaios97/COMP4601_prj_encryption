// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XAES_TOP_H
#define XAES_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xaes_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XAes_top_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XAes_top;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XAes_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XAes_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XAes_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XAes_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XAes_top_Initialize(XAes_top *InstancePtr, UINTPTR BaseAddress);
XAes_top_Config* XAes_top_LookupConfig(UINTPTR BaseAddress);
#else
int XAes_top_Initialize(XAes_top *InstancePtr, u16 DeviceId);
XAes_top_Config* XAes_top_LookupConfig(u16 DeviceId);
#endif
int XAes_top_CfgInitialize(XAes_top *InstancePtr, XAes_top_Config *ConfigPtr);
#else
int XAes_top_Initialize(XAes_top *InstancePtr, const char* InstanceName);
int XAes_top_Release(XAes_top *InstancePtr);
#endif

void XAes_top_Start(XAes_top *InstancePtr);
u32 XAes_top_IsDone(XAes_top *InstancePtr);
u32 XAes_top_IsIdle(XAes_top *InstancePtr);
u32 XAes_top_IsReady(XAes_top *InstancePtr);
void XAes_top_EnableAutoRestart(XAes_top *InstancePtr);
void XAes_top_DisableAutoRestart(XAes_top *InstancePtr);

u32 XAes_top_Get_in_r_BaseAddress(XAes_top *InstancePtr);
u32 XAes_top_Get_in_r_HighAddress(XAes_top *InstancePtr);
u32 XAes_top_Get_in_r_TotalBytes(XAes_top *InstancePtr);
u32 XAes_top_Get_in_r_BitWidth(XAes_top *InstancePtr);
u32 XAes_top_Get_in_r_Depth(XAes_top *InstancePtr);
u32 XAes_top_Write_in_r_Words(XAes_top *InstancePtr, int offset, word_type *data, int length);
u32 XAes_top_Read_in_r_Words(XAes_top *InstancePtr, int offset, word_type *data, int length);
u32 XAes_top_Write_in_r_Bytes(XAes_top *InstancePtr, int offset, char *data, int length);
u32 XAes_top_Read_in_r_Bytes(XAes_top *InstancePtr, int offset, char *data, int length);
u32 XAes_top_Get_out_r_BaseAddress(XAes_top *InstancePtr);
u32 XAes_top_Get_out_r_HighAddress(XAes_top *InstancePtr);
u32 XAes_top_Get_out_r_TotalBytes(XAes_top *InstancePtr);
u32 XAes_top_Get_out_r_BitWidth(XAes_top *InstancePtr);
u32 XAes_top_Get_out_r_Depth(XAes_top *InstancePtr);
u32 XAes_top_Write_out_r_Words(XAes_top *InstancePtr, int offset, word_type *data, int length);
u32 XAes_top_Read_out_r_Words(XAes_top *InstancePtr, int offset, word_type *data, int length);
u32 XAes_top_Write_out_r_Bytes(XAes_top *InstancePtr, int offset, char *data, int length);
u32 XAes_top_Read_out_r_Bytes(XAes_top *InstancePtr, int offset, char *data, int length);
u32 XAes_top_Get_w_BaseAddress(XAes_top *InstancePtr);
u32 XAes_top_Get_w_HighAddress(XAes_top *InstancePtr);
u32 XAes_top_Get_w_TotalBytes(XAes_top *InstancePtr);
u32 XAes_top_Get_w_BitWidth(XAes_top *InstancePtr);
u32 XAes_top_Get_w_Depth(XAes_top *InstancePtr);
u32 XAes_top_Write_w_Words(XAes_top *InstancePtr, int offset, word_type *data, int length);
u32 XAes_top_Read_w_Words(XAes_top *InstancePtr, int offset, word_type *data, int length);
u32 XAes_top_Write_w_Bytes(XAes_top *InstancePtr, int offset, char *data, int length);
u32 XAes_top_Read_w_Bytes(XAes_top *InstancePtr, int offset, char *data, int length);

void XAes_top_InterruptGlobalEnable(XAes_top *InstancePtr);
void XAes_top_InterruptGlobalDisable(XAes_top *InstancePtr);
void XAes_top_InterruptEnable(XAes_top *InstancePtr, u32 Mask);
void XAes_top_InterruptDisable(XAes_top *InstancePtr, u32 Mask);
void XAes_top_InterruptClear(XAes_top *InstancePtr, u32 Mask);
u32 XAes_top_InterruptGetEnabled(XAes_top *InstancePtr);
u32 XAes_top_InterruptGetStatus(XAes_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
